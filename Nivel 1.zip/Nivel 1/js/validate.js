const formRegistro = document.getElementById("myFormId");
const formLogin = document.getElementById("myFormId2");
const formBuscar = document.getElementById("mySearch");

//Función validación registro
function validacionRegistro() {

    var errores = 0;

    formRegistro.classList.remove("is-invalid");

    var usuario = document.forms["myForm"]["user"];
    var provincia = document.forms["myForm"]["provincia"];
    var correo = document.forms["myForm"]["email"];
    var contra = document.forms["myForm"]["pwd"];
    var contra2 = document.forms["myForm"]["pwd2"];
    var privacidad = document.forms["myForm"]["gridCheck"];

    if (usuario.value == "") {
        usuario.classList.add("is-invalid");
        document.getElementById("errorUsuario").textContent = "Debes introducir un nombre de usuario.";
        errores++;
    }

    if (provincia.value == "") {
        provincia.classList.add("is-invalid");
        document.getElementById("errorProvincia").textContent = "Debes seleccionar una provincia.";
        errores++;
    }

    if (correo.value == "") {
        correo.classList.add("is-invalid");
        document.getElementById("errorCorreo").textContent = "Debes introducir un correo electrónico.";
        errores++;
    } else if (!validarCorreo(correo.value)) {
        correo.classList.add("is-invalid");
        document.getElementById("errorCorreo").textContent = "Por favor, introduce un correo válido.";
        errores++;
    }

    if (contra.value == "") {
        contra.classList.add("is-invalid");
        document.getElementById("errorContra").textContent = "Debes introducir una contraseña.";
        errores++;
    }

    if (contra2.value == "") {
        contra2.classList.add("is-invalid");
        document.getElementById("errorContra2").textContent = "Debes introducir la confirmación de contraseña.";
        errores++;
    } else if (contra.value != contra2.value) {
        contra2.classList.add("is-invalid");
        document.getElementById("errorContra2").textContent = "Las contraseñas deben coincidir.";
        errores++;
    }

    if (!privacidad.checked) {
        privacidad.classList.add("is-invalid");
        document.getElementById("errorCheck").textContent = "Debes aceptar las condiciones.";
        errores++;
    }

    if (errores > 0) {
        return false;
    } else {
        return true;
    }
}

//Función validación Login
function validacionLogin() {

    var errores = 0;
    formLogin.classList.remove("is-invalid");

    var correo = document.forms["myForm2"]["email"];
    var contra = document.forms["myForm2"]["pwd"];

    if (correo.value == "") {
        correo.classList.add("is-invalid");
        document.getElementById("errorCorreoLogin").textContent = "Debes introducir un correo electrónico.";
        errores++;
    } else if (!validarCorreo(correo.value)) {
        correo.classList.add("is-invalid");
        document.getElementById("errorCorreoLogin").textContent = "Por favor, introduce un correo válido.";
        errores++;
    }

    if (contra.value == "") {
        contra.classList.add("is-invalid");
        document.getElementById("errorContraLogin").textContent = "Debes introducir una contraseña.";
        errores++;
    }

    if (errores > 0) {
        return false;
    } else {
        return true;
    }
}

//Función validación buscador
function validacionBusqueda() {

    var errores = 0;
    formBuscar.classList.remove("is-invalid");

    var buscar = document.forms["mySearch"]["busqueda"];

    if (buscar.value == "") {
        buscar.classList.add("is-invalid");
        document.getElementById("errorBusqueda").textContent = "Debes introducir una búsqueda.";
        errores++;
    } else if (buscar.value.length <= 3) {
        buscar.classList.add("is-invalid");
        document.getElementById("errorBusqueda").textContent = "La búsqueda debe tener más de 3 caracteres";
        errores++;
    }

    if (errores > 0) {
        return false;
    } else {
        return true;
    }
}


//Cuando quitamos el foco quitar clase is-invalid
formRegistro.addEventListener("blur", (event) => {
	console.log(event);
	if(event.target.value!="") event.target.classList.remove("is-invalid");
}, true);


formLogin.addEventListener("blur", (event) => {
	console.log(event);
	if(event.target.value!="") event.target.classList.remove("is-invalid");
}, true);

formBuscar.addEventListener("blur", (event) => {
	console.log(event);
	if(event.target.value!="") event.target.classList.remove("is-invalid");
}, true);



//Función validación correo electrónico
function validarCorreo(correo) {
    var comprobarCorreo = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if (comprobarCorreo.test(correo)) {
        return true;
    } else {
        return false;
    }
}